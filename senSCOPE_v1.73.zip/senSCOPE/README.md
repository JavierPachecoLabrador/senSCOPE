# senSCOPE
senSCOPE (Pacheco-Labrador et al., under review) is a modified version of the Soil Canopy Observation, Photochemistry and Energy fluxes 
  (SCOPE, Van der Tol at al. 2009) model, and mainly developped over the SCOPE code version 1.73. Therefore, the present version is 
  coordinated with the original code for consistency. senSCOPE adapts radiative transfer and plant function processes to represent
  canopies featuring mixed green and senescent leaves.

For general information about the functioning of SCOPE, check:
  Manual is available at ReadTheDocs https://scope-model.readthedocs.io/en/latest/ 