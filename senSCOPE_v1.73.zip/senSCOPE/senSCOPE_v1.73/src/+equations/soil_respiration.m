function [R] = soil_respiration(Ts)
R = 0 + 0*Ts;    %umol m-2 s-1