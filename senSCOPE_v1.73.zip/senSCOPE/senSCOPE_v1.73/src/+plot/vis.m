function vis()

plot(1:10)

end