Time is local WINTERTIME (GMT+1)
was corrected, because in the original files it was summertime (GMT + 2)