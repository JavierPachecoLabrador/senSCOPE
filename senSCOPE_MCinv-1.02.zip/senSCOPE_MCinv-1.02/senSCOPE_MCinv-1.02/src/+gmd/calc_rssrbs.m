function [rss,rbs] = calc_rssrbs(SMp,LAI,rbs)
% Help: This function applies the SMp-rss model calibrated in
% Pacheco-Labrador et al., 2019 in the site of Majadas de Tietar. This
% function is meant to overwrite the original fuction in the models SCOPE
% and senSCOPE. 
%   This code belongs to a package which is confidentially shared with the 
% reviewers of Pacheco-Labrador et al., GMD, under review. No further use 
% of this or other related unreleased code and data without express consent
% of the data producers. However, the models SCOPE and senSCOPE are publicly 
% available under GPL license, and are enought to run similar simulations 
% on different datasets.
% 
% References:    
%       Pacheco-Labrador, J., Perez-Priego, O., El-Madany, T.S., Julitta, T., Rossini, M., Guan, J., 
%   Moreno, G., Carvalhais, N., Mart�n, M.P., Gonzalez-Cascon, R., Kolle, O., Reischtein, M., van der 
%   Tol, C., Carrara, A., Martini, D., Hammer, T.W., Moossen, H., & Migliavacca, M. (2019). 
%   Multiple-constraint inversion of SCOPE. Evaluating the potential of GPP and SIF for the retrieval 
%   of plant functional traits. Remote Sensing of Environment, 234, 111362
%       Pacheco-Labrador, J., El-Madany, T.S., van der Tol, C., Martin, M.P., Gonzalez-Cascon, R., 
%   Perez-Priego, O., Guan, J., Moreno, G., Carrara, A., Reichstein, M., & Migliavacca, M. (under 
%   review). senSCOPE: Modeling radiative transfer and biochemical processes in mixed canopies 
%   combining green and senescent leaves with SCOPE. Geoscientific Model Development

SMp = 100*SMp;
rss            = 27224954.0171681490*exp((SMp).*(-2.6400554120)) + 14.0553096983./((SMp).^2);
rbs            = []; % % Leave it empty so that is later calculated from ustar