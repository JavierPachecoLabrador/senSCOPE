The functions in this folder are meant to replace some of the functions used by the SOCPE
and senSCOPE models and the respective moudles for inversion (SCOPE_MCinv) and (senSCOPE_MCinv) 
in the version of senSCOPE_MCinv_vGMD.m. This version of the code was used to produce the 
results of the artile Pacheco-Labrador et al., under review. This version only differs from 
the version available in GitHub (https://github.com/JavierPachecoLabrador) only in the use 
of additional variables measured/estimated at the specific site of Majadas de Tietar in the 
context of the SMANIE dataset. The version:
    1) Estimates of diffuse and direct solar irradiance, that replace
    the estimation done by default with SCOPE model from generic files 
    of atmospheric transfer functions
    2) The estimation of soil resistance to evaporation from the soil
    space using a different model than the used by SCOPE by default.
    3) The estimation of the bulk resistance as a function of ustar,
    according to Thom, 1972, instead of LAI as SCOPE does by default.
    4) Calculate d and zo according to Wallace and Verhoef 2003 


