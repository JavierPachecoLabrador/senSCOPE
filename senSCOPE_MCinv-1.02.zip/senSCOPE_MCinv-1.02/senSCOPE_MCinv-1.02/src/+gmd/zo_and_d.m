function [zo,d] = zo_and_d(canopy)
    zo = .13.*canopy.hc; %% According to Wallace and Verhoef 2003
    d = (2/3).*canopy.hc; %% According to Wallace and Verhoef 2003
end