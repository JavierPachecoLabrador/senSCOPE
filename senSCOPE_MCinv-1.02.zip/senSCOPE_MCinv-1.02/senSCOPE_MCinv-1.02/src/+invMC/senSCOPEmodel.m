function [R,fluxes,rad,thermal,profiles,soil,iter,Fgreen] = ...
    senSCOPEmodel(k,V,vi,vmax,soil,leafbio,canopy,meteo,angles,atmo,spectral,...
    optipar,directional,xyt,iter,options,Output_dir,Fg_NN)
% % HELP: senSCOPEmodel is a function runing the senSCOPE model, this is 
% % almost the same code that can be found in the cell "14. Run the model" 
% % of theoriginal senSCOPE model v1.73, converted into a function.
% % An additional option (options.store) is used to prevent storing results 
% % during inversion, but to be able to do it once the parametrs have been 
% % estimated. The function also provides the hemispherical-directional
% % reflectance factor in the observation as an output.
% % 
% % Input arguments:
% %     k: integer, index of the time series of inputs to simulate
% %     x: vector, model parameters to be evaluated
% %     V: structure, containing model inputs and inversion constraints
% %     vi: vector, position of the data corresponding to a given time step
% % in the V structure
% %     vmax: integer, maximum length of the time series
% %     soil: structure, contains SCOPE model soil parameters
% %     leafbio: structure, contains SCOPE model leaf biophysical and 
% % functional parameters
% %     canopy: structure, contains SCOPE model canopy structural
% % parameters
% %     meteo: structure, contains SCOPE model meteorological variables
% %     angles: structure, contains SCOPE model sun-view geometry variables
% %     atmo: structure, contains SCOPE model atmospheric transfer 
% % functions
% %     spectral: structure, contains SCOPE moel spectral features.
% %     optipar: structure, contains SCOPE model soil and vegetation 
% % optical constants
% %     directional: structure, contains SCOPE model multi-angular sun-view
% % geometry if meant to be computed
% %     xyt: structure, contains SCOPE spatial and temporal coordinates
% %     iter: structure, ,contains metaparameters for the energy balance
% %     observations: structure, contains the observational variables used
% % to constrain the inversion
% %     options: structure, contains SCOPE model options as well as 
% % additional options for the inversion
% %     Output_dir: string, contains the path where outputs will be stored
% %     Fg_NN: anonymous function, statistical model predicting Fgreen from
% % the variable leafbio
% % 
% % Output arguments: 
% %     R: vector, hemispherical-directional reflectance factor in the
% % direction of observation
% %     fluxes: structure, contains SCOPE model carbon and energy predicted 
% % fluxes
% %     rad: structure, contains SCOPE model predicted spectro-radiometric
% % variables
% %     thermal: structure, contains SCOPE model predicted thermal related
% % variables
% %     profiles: structure, contains SCOPE model predicted vertical
% % profiles of some variables
% %     soil: structure, contains SCOPE model soil parameters and some
% % predicted variables
% %     iter: structure, ,contains metaparameters for the energy balance
% % and returns information on the energy balance closure
% % 
% % Author: Javier Pacheco-Labrador, MPI-BGC, Jena, Germany. 2019-Sep-16
% % 
% % HISTORY:
% %     Created: Javier Pacheco-Labrador. 2019-Sep-16
% % 

 
%% Get some variables that need to be defined / preallocated
nwlP = length(spectral.wlP);
nwlT = length(spectral.wlT);
IwlP = spectral.IwlP;
IwlT = spectral.IwlT;
[rad,thermal,fluxes] = io.initialize_output_structures(spectral);
[rho,tau,rs,rho_green,tau_green,rho_senes,tau_senes] = deal(zeros(nwlP + nwlT,1));

%% Estimate Fgreen from averaged leaf parameters
canopy.Fgreen = Fg_NN(leafbio);

%% Generate green and senescent leaves
[leafbio_green,leafbio_senes] = deal(leafbio);
leafbio_green.Cs = 0;
if canopy.Fgreen>0
    leafbio_green.Cab   = leafbio.Cab./canopy.Fgreen;
    leafbio_green.Cca   = leafbio.Cca./canopy.Fgreen;
    leafbio_green.Cant  = leafbio.Cant./canopy.Fgreen;
    leafbio_green.Cw    = leafbio.Cw./(canopy.Fgreen + .25 - canopy.Fgreen * .25);
end

leafbio_senes.Cab	= 0;
leafbio_senes.Cca   = 0;
leafbio_senes.Cant  = 0;
leafbio_senes.Cdm   = leafbio.Cdm;
leafbio_senes.fqe   = 0;
if canopy.Fgreen<1
    leafbio_senes.Cw= (leafbio.Cw  - leafbio_green.Cw*canopy.Fgreen)./(1-canopy.Fgreen);
    leafbio_senes.Cs      = leafbio.Cs./(1-canopy.Fgreen);
end


%% Run model
    if options.simulation ~=1
% %         fprintf('simulation %i ', k );
% %         fprintf('of %i \n', telmax);
    else
        calculate = 0;
%         if k>=I_tmin && k<=I_tmax
            quality_is_ok   = ~isnan(meteo.p*meteo.Ta*meteo.ea*meteo.u.*meteo.Rin.*meteo.Rli);
% %             fprintf('time = %4.2f \n', xyt.t(k));
            if quality_is_ok
                calculate = 1;
            end
%         end
    end
    
    if calculate        
        iter.counter = 0;
        
%         LIDF_file            = char(F(22).FileName);
%         if  ~isempty(LIDF_file)
%             canopy.lidf     = dlmread([path_input,'leafangles/',LIDF_file],'',3,0);
%         else
        canopy.lidf     = equations.leafangles(canopy.LIDFa,canopy.LIDFb);    % This is 'ladgen' in the original SAIL model,
%         end
        
        if options.calc_PSI
            fversion = @fluspect_B_CX;
        else
            fversion = @fluspect_B_CX_PSI_PSII_combined;
        end

        
        
%       Calculate optical properties of green and senescent leaves 
%       separately and combine them accordingly to their respective leaf 
%       area fractions.
        [leafbio_green.V2Z,leafbio_senes.V2Z] = deal(0);
        leafopt_green  = fversion(spectral,leafbio_green,optipar);
        leafopt_senes  = fversion(spectral,leafbio_senes,optipar);
        
        [leafbio_green.V2Z,leafbio_senes.V2Z] = deal(1);
        leafoptZ_green = fversion(spectral,leafbio_green,optipar); 
        leafoptZ_senes = fversion(spectral,leafbio_senes,optipar);
        
%       Weighted average of optical properties
%       Here, the variables refl, tran, kchrel and the EF-matrices are 
%       averaged. This avoids multiplying other variables by the leaf area 
%       fractions later. This is equivalent but not exactly as described in 
%       Eq. 5,6 and 17 of the manuscript (Pacheco-Labrador et al., under review)
        fnms_av = fieldnames(leafopt_green); % This should be done only once in the loop
        leafopt = cell2struct(cell(length(fnms_av),1),fnms_av); 
        leafoptZ = struct('refl',[],'tran',[]);
        for ij = 1:length(fnms_av)    
            if isfield(leafopt_senes,fnms_av{ij})
                leafopt.(fnms_av{ij}) = canopy.Fgreen*leafopt_green.(fnms_av{ij}) +...
                    (1-canopy.Fgreen)*leafopt_senes.(fnms_av{ij});
            else % % EF-matrices
                leafopt.(fnms_av{ij}) = canopy.Fgreen*leafopt_green.(fnms_av{ij});
            end
            % % Average only refl and tran for leafoptZ
            if ij<3
                leafoptZ.(fnms_av{ij}) = canopy.Fgreen*leafoptZ_green.(fnms_av{ij}) +...
                    (1-canopy.Fgreen)*leafoptZ_senes.(fnms_av{ij});
            end            
        end
        
        IwlP     = spectral.IwlP;
        IwlT     = spectral.IwlT;
        
        rho(IwlP)  = leafopt.refl;
        tau(IwlP)  = leafopt.tran;
        
        rho_green(IwlP)  = leafopt_green.refl;
        tau_green(IwlP)  = leafopt_green.tran;
        rho_senes(IwlP)  = leafopt_senes.refl;
        tau_senes(IwlP)  = leafopt_senes.tran;

        rlast    = rho(nwlP);
        tlast    = tau(nwlP);
        
        rlast_green    = rho_green(nwlP);
        tlast_green    = tau_green(nwlP);
        rlast_senes    = rho_senes(nwlP);
        tlast_senes    = tau_senes(nwlP);
        
        if options.soilspectrum == 0
            rs(IwlP) = rsfile(:,soil.spectrum+1);
        else
            soilemp.SMC   = 25;        % empirical parameter (fixed)
            soilemp.film  = 0.015;     % empirical parameter (fixed)
%             Use these parameters for SMANIE data
%             soilemp.SMC   = 43.29;        % empirical parameter (fixed)
%             soilemp.film  = 0.012;     % empirical parameter (fixed)
            rs(IwlP) = BSM(soil,optipar,soilemp);
        end
        rslast   = rs(nwlP);
        
        switch options.rt_thermal
            case 0
                [rho(IwlT),rho_green(IwlT),rho_senes(IwlT)] = deal(ones(nwlT,1) * leafbio.rho_thermal);
                [tau(IwlT),tau_green(IwlT),tau_senes(IwlT)] = deal(ones(nwlT,1) * leafbio.tau_thermal);
                rs(IwlT)  = ones(nwlT,1) * soil.rs_thermal;
            case 1
                rho(IwlT) = ones(nwlT,1) * rlast;
                tau(IwlT) = ones(nwlT,1) * tlast;
                rho_green(IwlT) = ones(nwlT,1) * rlast_green;
                tau_green(IwlT) = ones(nwlT,1) * tlast_green;
                rho_senes(IwlT) = ones(nwlT,1) * rlast_senes;
                tau_senes(IwlT) = ones(nwlT,1) * tlast_senes;
                rs(IwlT)  = ones(nwlT,1) * rslast;
        end
        
        leafopt.refl = rho;     % extended wavelength ranges are stored in structures
        leafopt.tran = tau;
        
        reflZ = leafopt.refl;
        tranZ = leafopt.tran;
        reflZ(1:300) = leafoptZ.refl(1:300);
        tranZ(1:300) = leafoptZ.tran(1:300);
        leafopt.reflZ = reflZ;
        leafopt.tranZ = tranZ;
        
%       Compute also absorptances (emittances) of the green and the 
%       senescent leaves separately to speed up calculation of the energy
%       balance and the RTMo. Absorptances are already scaled by leaf area 
%       fraction, avoiding to do this in RTM_sb and RTMo.
        leafopt.abso_green = (1 - rho_green - tau_green)*canopy.Fgreen;
        leafopt.abso_senes = (1 - rho_senes - tau_senes)*(1-canopy.Fgreen);
        
        soil.refl    = rs;
        
        soil.Ts     = meteo.Ta * ones(2,1);       % initial soil surface temperature
        
% %         if length(F(4).FileName)>1 && options.simulation==0
% %             atmfile     = [path_input 'radiationdata/' char(F(4).FileName(k))];
% %             atmo.M      = helpers.aggreg(atmfile,spectral.SCOPEspec);
% %         end
        atmo.Ta     = meteo.Ta;
        
%       RTMo() is adapted to senSCOPE        
        [rad,gap,profiles]   = RTMo(spectral,atmo,soil,leafopt,canopy,angles,meteo,rad,options);
        
        switch options.calc_ebal
            case 1
                % ebal() is adapted to senSCOPE
                [iter,fluxes,rad,thermal,profiles,soil]                          ...
                    = ebal(iter,options,spectral,rad,gap,                       ...
                    leafopt,angles,meteo,soil,canopy,leafbio_green,xyt,k,profiles);

                % RTMf() does not need to be modified.
                if options.calc_fluor
                    if options.calc_vert_profiles
                        [rad,profiles] = RTMf(spectral,rad,soil,leafopt,canopy,gap,angles,profiles);
                    else
                        [rad] = RTMf(spectral,rad,soil,leafopt,canopy,gap,angles,profiles);
                    end
                end
                
                % RTMz() does not need to be modified.
                if options.calc_xanthophyllabs
                    [rad] = RTMz(spectral,rad,soil,leafopt,canopy,gap,angles,profiles);
                end
                
                % RTMt_planck() is adapted to senSCOPE
                if options.calc_planck
                    rad         = RTMt_planck(spectral,rad,soil,leafopt,canopy,gap,angles,...
                        thermal.Tcu_green,thermal.Tch_green,thermal.Tcu_senes,thermal.Tch_senes,thermal.Ts(2),thermal.Ts(1),1);
                end
               
                % calc_brdf() does not need to be modified.
                if options.calc_directional
                    directional = calc_brdf(options,directional,spectral,angles,rad,atmo,soil,leafopt,canopy,meteo,profiles,thermal);
                end
                
            otherwise
                Fc              = (1-gap.Ps(1:end-1))'/nl;      %           Matrix containing values for Ps of canopy
                fluxes.aPAR     = canopy.LAI*(Fc*rad.Pnh        + equations.meanleaf(canopy,rad.Pnu    , 'angles_and_layers',gap.Ps));% net PAR leaves
                fluxes.aPAR_Cab = canopy.LAI*(Fc*rad.Pnh_Cab    + equations.meanleaf(canopy,rad.Pnu_Cab, 'angles_and_layers',gap.Ps));% net PAR leaves
                fluxes.aPAR_Wm2 = canopy.LAI*(Fc*rad.Rnh_PAR    + equations.meanleaf(canopy,rad.Rnu_PAR, 'angles_and_layers',gap.Ps));% net PAR leaves
                fluxes.aPAR_Cab_eta = canopy.LAI*(Fc*rad.Rnh_PAR_green    + equations.meanleaf(canopy,rad.Rnu_PAR_green, 'angles_and_layers',gap.Ps));% net PAR leaves
                % RTMz() does not need to be modified.
                if options.calc_fluor
                    profiles.etah = ones(60,1);
                    profiles.etau = ones(13,36,60);
                    if options.calc_vert_profiles
                        [rad,profiles] = RTMf(spectral,rad,soil,leafopt,canopy,gap,angles,profiles);
                    else
                        [rad] = RTMf(spectral,rad,soil,leafopt,canopy,gap,angles,profiles);
                    end
                end
        end
        
        % % There is on need to modify this part since aPAR is already provided 
        % % per total leaf area. Thus, green leaf fqe can be used directly.
        if options.calc_fluor % total emitted fluorescence irradiance (excluding leaf and canopy re-absorption and scattering)
            if options.calc_PSI
                rad.Femtot = 1E3*(leafbio_green.fqe(2)* optipar.phiII(spectral.IwlF) * fluxes.aPAR_Cab_eta +leafbio_green.fqe(1)* optipar.phiI(spectral.IwlF)  * fluxes.aPAR_Cab);
            else
                rad.Femtot = 1E3*leafbio_green.fqe* optipar.phi(spectral.IwlF) * fluxes.aPAR_Cab_eta;
            end
        end   
        
        if options.store
            io.output_data(Output_dir, options, k, iter, xyt, fluxes, rad, thermal, gap, meteo, spectral, V, vi, vmax, profiles, directional, angles)
        end
    end
    
%%  Copmute reflectance factor
if options.calc_fluor
    SIF = zeros(length(IwlP),1);
    SIF(spectral.IwlF) = rad.LoF_; %% clf; plot(spectral.wlP,SIF)
else
    SIF = 0;
end

% % rad.Lo_ includes Xanthophylls' effect calculated by RTMz 
R = (rad.Lo_(IwlP).*pi + SIF)./(rad.Esky_ (IwlP) + rad.Esun_(IwlP));

%%  Output Fgreen
if nargout>=8
    Fgreen = canopy.Fgreen;
end

end