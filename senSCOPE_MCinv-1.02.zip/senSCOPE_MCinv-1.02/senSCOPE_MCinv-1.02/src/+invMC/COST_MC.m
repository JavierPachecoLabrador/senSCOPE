function [err] = COST_MC(x,V,vi,vmax,soil,leafbio,canopy,meteo,angles,atmo,spectral,...
    optipar,directional,xyt,iter,observations,Fg_NN,options,Output_dir,priors)
% % HELP: This function calculates the cost of a given set of parameters
% % comparing SCOPE model predictions with observations. The function can
% % compute cost of the both Step #1 and #2 of the inverison approach
% % proposed by Pacheco-Labrador et al., in press. This function must be
% % passed via an anonymous function to an optimization algorithm for the
% % retrieval of SCOPE parameters
% % 
% % Input arguments:
% %     x: vector, model parameters to be evaluated
% %     V: structure, containing model inputs and inversion constraints
% %     vi: vector, position of the data corresponding to a given time step
% % in the V structure
% %     vmax: integer, maximum length of the time series
% %     soil: structure, contains SCOPE model soil parameters
% %     leafbio: structure, contains SCOPE model leaf biophysical and 
% % functional parameters
% %     canopiy: structure, contains SCOPE model canopy structural
% % parameters
% %     meteo: structure, contains SCOPE model meteorological variables
% %     angles: structure, contains SCOPE model sun-view geometry variables
% %     atmo: structure, contains SCOPE model atmospheric transfer 
% % functions
% %     spectral: structure, contains SCOPE moel spectral features.
% %     optipar: structure, contains SCOPE model soil and vegetation 
% % optical constants
% %     directional: structure, contains SCOPE model multi-angular sun-view
% % geometry if meant to be computed
% %     xyt: structure, contains SCOPE spatial and temporal coordinates
% %     iter: structure, ,contains metaparameters for the energy balance
% %     observations: structure, contains the observational variables used
% % to constrain the inversion
% %     Fg_NN: anonymous function, statistical model predicting Fgreen from
% % the variable leafbio
% %     options: structure, contains SCOPE model options as well as 
% % additional options for the inversion
% %     Output_dir: string, contains the path where outputs will be stored
% %     priors: structure, contains priors imposed to the inversion (both
% % mean value and uncertainty)
% % 
% % Output argument: 
% %     err: vector, cost of the evaluated set of parameters
% % 
% % Author: Javier Pacheco-Labrador, MPI-BGC, Jena, Germany. 2019-Nov-05
% % 
% % HISTORY:
% %     Created: Javier Pacheco-Labrador. 2019-Nov-05
% % 
 
%% Assign parameters to structures
j = 1;
for i = 1:length(options.params_sel)
    if options.params_sel(i) && strcmp(options.params_inv(i,1),'leafbio')
        leafbio.(options.params_inv{i,2}) = x(j);
        j = j + 1;        
    elseif options.params_sel(i) && strcmp(options.params_inv(i,1),'canopy')
        canopy.(options.params_inv{i,2}) = x(j);
        j = j + 1;        
    end    
end

% % Back-transform LIDF parameters
if options.params_sel(strcmp(options.params_inv(:,2),'LIDFa'))
    LIDFa = (canopy.LIDFa + canopy.LIDFb)/2;
    LIDFb = (canopy.LIDFa - canopy.LIDFb)/2;
    canopy.LIDFa = LIDFa;
    canopy.LIDFb = LIDFb;    
end

%% Step #1
if options.inv_step(1) && ~options.inv_step(2)
    % % Run model
    % %     Notice that in this case, vi is actually k, but passed from 
    % % otuside the function
    try
        [R,fluxes,rad] = invMC.senSCOPEmodel(vi,V,[],vmax,soil,leafbio,canopy,meteo,angles,...
            atmo,spectral,optipar,directional,xyt,iter,options,[],Fg_NN);
    catch
       x = 1; 
    end

    % % Compute cost
    % % Reflectance factor. Since it is a smooth shape, spectral convolution
    % % could be overkilling. Linear interpolation is used to predict R at the
    % % wavelengths of the sensor providing observational R.
    Rint = interp1(spectral.wlP,R,observations.R(:,1));
    err_hdrf = zeros(size(Rint));
    I = ~isnan(Rint) & ~isinf(Rint);
    
    err_hdrf(I) = ( Rint(I) - observations.R(I,2) ) ./ (observations.R_u(I,2) * length(Rint));
    
    % % GPP
    if options.constraints.GPP
        err_GPP = (fluxes.Atot - observations.GPP) ./ max(observations.GPP_u, 0.4); % % Prevent too low values inflating weight
    else
        err_GPP = [];
    end
    
    % % F760
    if options.constraints.F760
        err_F760 = (rad.LoF_(spectral.wlF==760) - observations.F760) ./ (observations.F760_u * 10);  % % Prevent too low values inflating weight
    else
        err_F760 = [];
    end
    
    % % Preallocate
    err_Vcmo = [];

else
    [err_hdrf,err_GPP,err_F760] = deal([]);
end

%% Step #2
if options.inv_step(2)
% % Preallocate
    telmax = length(xyt.t);
    [err_GPP,err_Ltir] = deal(zeros(telmax,1));
    
    for k = 1:telmax
        try
            % % Sometimes the biochemical module fails to find a solution
            % % within a given number of iterations. To prevent crashing
            % % the whole inversion, at try catch is used
            vi(vmax>1) = k;
            % % Update inputs
            [soil,~,~,~,meteo,angles,xyt,observations] = invMC.select_input(V,vi,canopy,options,xyt,soil);

            % % Run model.
            % % Notice that here vi is actually vi
            [R,fluxes,rad] = invMC.senSCOPEmodel(k,V,vi,vmax,soil,leafbio,canopy,meteo,angles,atmo,...
                spectral,optipar,directional,xyt,iter,options,[],Fg_NN);

            % % Compute cost
            if options.inv_step(1) && observations.R_flux_match(k)
            % % This can be got here if both steps are asked for, so that the 
            % % Jacobian of the final solution can be computed.        
                % % Reflectance factor. Since it is a smooth shape, spectral convolution
                % % could be overkilling. Linear interpolation is used to predict R at the
                % % wavelengths of the sensor providing observational R.
                Rint = interp1(spectral.wlP,R,observations.R(:,1));
                err_hdrf = zeros(size(Rint));
                I = ~isnan(Rint) & ~isinf(Rint);
                err_hdrf(I) = ( Rint(I) - observations.R(I,2) ) ./ (observations.R_u(I,2) * length(Rint));
            end

            % % GPP
            if options.constraints.GPP                
                err_GPP(k) = (fluxes.Atot - observations.GPP) ./ ( max(observations.GPP_u, .4) * telmax); % % Prevent too low values inflating weight
            else
                err_GPP = [];
            end
            
            % % F760, only at midday
            if options.constraints.F760 && observations.R_flux_match(k)
                err_F760 = (rad.LoF_(spectral.wlF==760) - observations.F760) ./ ( observations.F760_u * 10 * telmax); % % Prevent too low values inflating weight
            else
                err_F760 = [];
            end

            % % Ltir
            Ltir_pred = invMC.apogeeLtir(rad,spectral);
            err_Ltir(k) = (Ltir_pred - observations.Ltir) ./ ( observations.Ltir_u * telmax);
    
        catch
            if options.constraints.GPP; err_GPP(k)   = observations.GPP;	else	err_GPP = []; end
            if options.constraints.GPP && observations.R_flux_match(k)
                err_F760(k)  = observations.F760;   
            else
                err_F760 = []; 
            end
            err_Ltir(k) = observations.Ltir;
        end
    end
    
    % % Regularization of Vcmo    
    err_Vcmo = (leafbio.Vcmo - priors.Vcmo(1)) ./ max(priors.Vcmo(2),5);
    
else
    % % Do not overwrite err_GPP in Step #1
    err_Ltir = [];
end

%% Total cost
err = [err_hdrf; err_GPP; err_F760; err_Ltir; err_Vcmo];

end